import { useState } from 'react';

function Todolist(){
    const [todo, setTodo] = useState({description: "", duedate: ""});
    const [todos, setTodos] = useState([]);

    const handleAdd = () => {
    
        if(!todo.description || !todo.duedate) {
                alert("Please enter a todo");
            }
        else {
            setTodos([todo, ...todos]);
            setTodo({description: "", duedate: ""});
            }
        
    }

    return(
        <>
            <h3>My Todos</h3>
            <input 
                placeholder='Description'
                value={todo.description}
                onChange={(e) => setTodo({...todo, description: e.target.value})}
            />
            <input 
                placeholder='Due date'
                value={todo.duedate}
                onChange={(e) => setTodo({...todo, duedate: e.target.value})}
            />
            <button onClick={handleAdd}>Add Todo</button>
            <table>
                <tbody>
                {
                todos.map((todo, index) =>
                <tr key={index}>
                    <td>{todo.description}</td>
                    <td>{todo.duedate}</td>
                    
                </tr>
                )
                }
                </tbody>
            </table>
        </>
    );
}

export default Todolist;
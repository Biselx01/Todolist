import { useState } from 'react';
import TodoTable from './TodoTable';

function Todolist(){
    const [todo, setTodo] = useState({description: "", duedate: ""});
    const [todos, setTodos] = useState([]);

    const handleAdd = () => {
        if(!todo.description || !todo.duedate) {
            alert("Please enter a todo");
        } else {
            setTodos([todo, ...todos]);
            setTodo({description: "", duedate: ""});
        }
    }

    const handleDelete = (row) => {
        setTodos(todos.filter((todo, index) => row !== index));
    }

    return(
        <>
            <h3>My Todos</h3>
            <input 
                placeholder='Description'
                value={todo.description}
                onChange={(e) => setTodo({...todo, description: e.target.value})}
            />
            <input 
                type="date"
                value={todo.duedate}
                onChange={(e) => setTodo({...todo, duedate: e.target.value})}
            />
            <button onClick={handleAdd}>Add Todo</button>
            <TodoTable todos={todos} handleDelete={handleDelete}/>
        </>
    );
}

export default Todolist;
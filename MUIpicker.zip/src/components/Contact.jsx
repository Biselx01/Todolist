export default function Contact() {
  return(<h1>Email: myapp@contact.com</h1>);
}
import { useState, useRef } from 'react';

import { AgGridReact } from 'ag-grid-react'; 
import "ag-grid-community/styles/ag-grid.css"; 
import "ag-grid-community/styles/ag-theme-material.css";

function Todolist(){
    const [todo, setTodo] = useState({description: "", priority: "", duedate: ""});
    const [todos, setTodos] = useState([]);
    const [colDefs] = useState([
        {field: "description", filter: true, floatingFilter: true, checkboxSelection: true},
         { field: "priority", filter: true, floatingFilter: true, sortable: true,
        cellStyle: params => params.value === "High" ? {color: 'red'} : {color: 'black'}
      },
        {field: "duedate", filter: true, floatingFilter: true},
    ]);
    const gridRef = useRef();

    const handleAdd = () => {
        if(!todo.description || !todo.duedate || !todo.priority) {
            alert("Please enter a todo");
        } else {
            setTodos([todo, ...todos]);
            setTodo({description: "", duedate: "", priority: ""});
        }
    }

    const handleDelete = () => {
        if(gridRef.current.getSelectedNodes().length > 0){

        
        setTodos(todos.filter((_, index) => 
            gridRef.current.getSelectedNodes()[0].id != index));
        } else {
        alert("Please select a todo to delete");
        }
    }

    return(
        <>
            <h3>My Todos</h3>
            <input 
                placeholder='Description'
                value={todo.description}
                onChange={(e) => setTodo({...todo, description: e.target.value})}
            />
            <select 
                value={todo.priority}
                onChange={(e) => setTodo({...todo, priority: e.target.value})}
            >
                <option value="">Select Priority</option>
                <option value="Low">Low</option>
                <option value="Medium">Medium</option>
                <option value="High">High</option>
            </select>
            <input 
                type="date"
                value={todo.duedate}
                onChange={(e) => setTodo({...todo, duedate: e.target.value})}
            />
           
            <button onClick={handleAdd}>Add Todo</button>
            <button onClick={handleDelete}>Delete</button>
          
            <div
            className="ag-theme-material" 
            style={{ height: 500, width: '103%'}}
            >
            <AgGridReact
                ref={gridRef}
                onGridReady={ params => gridRef.current = params.api}
                rowData={todos}
                columnDefs={colDefs}
                rowSelection = 'single'
            />
            </div>

        </>
    );
}

export default Todolist;
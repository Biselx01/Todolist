import { useState } from 'react'
import Container from '@mui/material/Container'
import CssBaseline from '@mui/material/CssBaseline'
import AppBar from '@mui/material/AppBar'
import Toolbar from '@mui/material/Toolbar'
import Typography from '@mui/material/Typography'
import { Link, Outlet } from 'react-router-dom';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import MenuIcon from '@mui/icons-material/Menu';
import IconButton from '@mui/material/IconButton';


function App() {
    const [anchorEl, setAnchorEl] = useState(null);

  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

return (
    <Container maxWidth='lg'>
      <AppBar position='static'>
        <Toolbar>
          <Typography variant="h6" sx={{ flexGrow: 1 }}>
            My Todos
          </Typography>
          <IconButton
            aria-controls="simple-menu"
            aria-haspopup="true"
            onClick={handleMenuOpen}
            color="inherit"
               sx={{
              transform: anchorEl ? 'rotate(90deg)' : 'rotate(0deg)',
              transition: 'transform 0.3s',
            }}
          >
            <MenuIcon />
          </IconButton>
          <Menu
            id="simple-menu"
            anchorEl={anchorEl}
            keepMounted
            open={Boolean(anchorEl)}
            onClose={handleMenuClose}
          >
            <MenuItem onClick={handleMenuClose}>
              <Link to="/" underline="hover">Home</Link>
            </MenuItem>
            <MenuItem onClick={handleMenuClose}>
              <Link to="/todolist" underline="hover">Todolist</Link>
            </MenuItem>
            <MenuItem onClick={handleMenuClose}>
              <Link to="/about" underline="hover">About</Link>
            </MenuItem>
            <MenuItem onClick={handleMenuClose}>
              <Link to="/contact" underline="hover">Contact</Link>
            </MenuItem>
          </Menu>
        </Toolbar>
      </AppBar>
      <Outlet />
      <CssBaseline />
    </Container>
  );
}

export default App

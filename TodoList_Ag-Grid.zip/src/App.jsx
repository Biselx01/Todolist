import './App.css'
import Todolist from './components/Todolist'

function App() {

  return (
    <>
      <Todolist />
    </>
  )
}

export default App
